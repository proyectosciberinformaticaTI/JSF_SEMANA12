package com.mitocode.service;

import com.mitocode.model.Puesto;

public interface IPuestoService extends IService<Puesto> {

}
