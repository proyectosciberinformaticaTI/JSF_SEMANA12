package com.mitocode.dao;

import javax.ejb.Local;

import com.mitocode.model.Puesto;

@Local
public interface IPuestoDAO extends IDAO<Puesto> {

}
